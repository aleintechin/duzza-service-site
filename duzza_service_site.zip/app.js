const app = document.getElementById('app');

function loadPage(page) {
  fetch(`pages/${page}.html`)
    .then(res => res.text())
    .then(data => app.innerHTML = data)
    .catch(() => app.innerHTML = '<h2>Page not found</h2>');
}

window.addEventListener('load', () => {
  const hash = window.location.hash.replace('#', '') || 'home';
  loadPage(hash);
});

window.addEventListener('hashchange', () => {
  const hash = window.location.hash.replace('#', '');
  loadPage(hash);
});